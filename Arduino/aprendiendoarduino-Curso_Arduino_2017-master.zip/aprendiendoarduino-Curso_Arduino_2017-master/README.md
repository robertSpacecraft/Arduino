# aprendiendoarduino - Curso Arduino 2017
### Prácticas para Curso Arduino 2017

Este repositorio contiene las prácticas y el código del **Curso Arduino 2017** de www.aprendiendoarduino.com

La documentación del curso está disponible en http://www.aprendiendoarduino.com/curso-arduino-2017/
