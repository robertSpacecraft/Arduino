# NTP Basic
Obtener fecha y hora en Arduino sin necesidad de un RTC usando NTP
NTP: https://es.wikipedia.org/wiki/Network_Time_Protocol